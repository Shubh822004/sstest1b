package com.example.shubhneetsingh;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.util.Objects;

public class HelloController {
    public TextField username;
    public PasswordField password;

    public Label errmsg;

    @FXML
    public Label welcomeText;
    static int invalidReqcount=0;

    static String correctusername="Shubh";
    static String correctpassword="12345678";

    public void onHelloButtonClick(ActionEvent actionEvent) {
        String usernameInput=username.getText();
        String passwordInput=password.getText();

        if (usernameInput.isEmpty()|| passwordInput.isEmpty()){
            errmsg.setText("Please provide username or password");
        }
        else if (invalidReqcount==5){
            errmsg.setText("Sorry, your account is locked!!!" );
        }
        else   if (usernameInput.equals(correctusername) && passwordInput.equals(correctpassword)){
            errmsg.setText("you are logged in succesfully");
            invalidReqcount=0;
        }
        else { errmsg.setText("Sorry, Invalid username or Password.");
            invalidReqcount++;

}

    }
    }

