module com.example.shubhneetsingh {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.shubhneetsingh to javafx.fxml;
    exports com.example.shubhneetsingh;
}